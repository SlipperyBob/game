#include "Entity.h"
#include "config.h"
#include "Field.h"
#include <iostream>


void Entity::draw(Image &screen, CameraController camera) {
    if (!camera.isSpriteVisible(getSpritePos())) return;

    Image *toDraw;
    Image *toDraw_t;
    if (animationState > 0) {
        animationState -=2;
        idleState = 0;
    }

    if (deathState > 0) {
        int d = 3 - 4 * deathState /fps;
        toDraw = textures->death[d];
        screen.putSprite(getSpritePos().x, getSpritePos().y + 5, *toDraw, camera);
        deathState = std::max(deathState - 1, 1);
        return;
    }
    
    bool left = looksLeft();
    int k = 3 - 4 * idleState / fps;
    toDraw = left ? textures->bottom_left[k] : textures->bottom_right[k];
    toDraw_t = left ? textures->top_left[k] : textures->top_right[k];
    
    idleState = (idleState + 1)%fps;

    if (damagedState <= 0) {
        screen.putSprite(getSpritePos().x, getSpritePos().y, *toDraw, camera);
        screen.putSprite(getSpritePos().x, getSpritePos().y + TILE_SIZE, *toDraw_t, camera);
    } else {
        screen.putSprite(getSpritePos().x, getSpritePos().y, *toDraw, camera, red);
        screen.putSprite(getSpritePos().x, getSpritePos().y + TILE_SIZE, *toDraw_t, camera, red);
        damagedState--;
        if (damagedState == 0) {
            deathState = fps/2;
        }
    }

}

Point Entity::getSpritePos() {
    if (animationState == 0) return Point(pos.x * TILE_SIZE, GRID_SIZE*TILE_SIZE - pos.y * TILE_SIZE);
    else {
        return Point(pos.x * TILE_SIZE, GRID_SIZE*TILE_SIZE - pos.y * TILE_SIZE) - 
            Point (animationState * dirToVec(direction).x, -animationState * dirToVec(direction).y);
    }
}

void Entity::makeMove(MovementDir dir) {
    updatePrevPos();
    animationState = TILE_SIZE - 2;
    pos += dirToVec(dir);
}

void Entity::setDirection(MovementDir dir) {
    direction = dir;
    if (dir == MovementDir::LEFT || dir == MovementDir::RIGHT) {
        turnDir = dir;
    }
}
