#include "Player.h"
#include "config.h"
#include "Sprites.h"
#include "Field.h"
#include <iostream>

Player::Player(Field* _field, Point position) : Entity(_field, position) {
    Sprites *sprites = Sprites::GetInstance();
    textures = sprites->hero;
    name = "Player";
}

bool Player::move(MovementDir dir) {
    bool moved = false;
   
   Point p = pos + dirToVec(dir);
    if (field->isValid(p)) {
        makeMove(dir);
        moved = true;
    }
    setDirection(dir);
    return moved;
}
